public class Main {
    public static void main(String[] args) {

        System.out.printf( "%.2f , %.2f , %.2f" , 3.222222 ,  4.333333 , 5.444444 );
    }
}