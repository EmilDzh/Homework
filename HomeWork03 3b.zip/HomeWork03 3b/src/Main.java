public class Main {
    public static void main(String[] args) {

        System.out.printf("3.22 " + " 4.33" + " 5.44");
    }
}