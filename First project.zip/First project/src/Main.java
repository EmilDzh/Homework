import static java.lang.System.out;

public class Main {
    public static void main(String[] args) {
        out.println("Hello Emil!");
        out.println();
        out.println(10);
        out.println("10");
        out.println("3.14");
        out.println(" ich liebe Java " + " JavaMan " +  666 );
        out.println("1");
        out.println("2");
        out.println("3");
        out.print("1 ");
        out.print("2 ");
        out.print("3 ");
        out.println("2" + "2");
        out.println(2 + 2);
        out.println("2" + "2");
        System.out.printf(
                "Строка с ключами, в которой %s вместо s, %d вместо d, снова %s, а ещё есть %.2f", "ABC"
                , 10, 3.14159, 3.14159);
    }
}