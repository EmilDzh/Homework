public class Main {
    public static void main(String[] args) {
        System.out.println("Привет, меня зовут ED Sheeran!");
        System.out.println("мне 23 года ");
        System.out.println("мой Рост 1.73 ");
        System.out.println();
        System.out.println("Привет, меня зовут Elliot Anderson" );
        System.out.println("мне 28" );
        System.out.println("Рост 1.74" );
        System.out.println();
        System.out.println("Добрый Вечер, зовут меня Durin 2");
        System.out.println("мне 120 лет");
        System.out.println("Рост 1.30");

        
    }
}