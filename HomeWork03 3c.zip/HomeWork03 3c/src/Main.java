public class Main {
    public static void main(String[] args) {

        System.out.print("-") ;
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.println();
        System.out.print("|");
        System.out.print("не уверен,что " );
        System.out.println("   |");
        System.out.print("|");
        System.out.print("это прямоугольник");
        System.out.println("|");
        System.out.print("|");
        System.out.print("но сделал все что");
        System.out.println("|");
        System.out.print("|");
        System.out.print("мог xD");
        System.out.println("           |");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");


    }
}